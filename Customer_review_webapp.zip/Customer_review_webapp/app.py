import os

from flask import Flask,render_template,redirect,url_for,request,flash
from wtforms import Form,TextField,TextAreaField,validators,StringField,SubmitField
from wtforms.validators import DataRequired, Length
def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY='dev',
        DATABASE=os.path.join(app.instance_path, 'flaskr.sqlite'),
    )

    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile('config.py', silent=True)
    else:
        # load the test config if passed in
        app.config.from_mapping(test_config)

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    # a simple page that says hello
    class Review_Form(Form):
        
        reset=SubmitField('Reset')
        name=TextField("First Name *",validators=[validators.DataRequired()])
        product=TextField("Product Name *",validators=[validators.DataRequired()])
        review=TextAreaField("Text Area",validators=[validators.DataRequired()])
        submit = SubmitField('Submit')
        
        
        
        


    def csv(name,review,product ):
        f=open("reviewfile4.csv","a+")
        
        f.write(str(name)+","+str(product)+","+str(review)+"\n")
        f.close()     
        

        
    @app.route('/', methods=["GET","POST"])    
    def review():
        
        form=Review_Form()
        #if request.method=="POST":
        review1=request.form.get("review")
        name=request.form.get("name")
        product=request.form.get("product")
        f=open("reviewfile4.csv","a+")
        data=[]
        for i in f:
                    j=list(i.split(","))
                    #for j in li:
                    data.append({
                                "Name": j[0],
                                "Product": j[1],
                                "Review": j[2]
                                })
        if request.form.get("submit"):
            
            csv(name,review1,product)
            
            return render_template("index.html",data=data,form=form)
        elif request.form.get("reset"):
            f=open("reviewfile4.csv","r+")
            f.truncate(0)
            return render_template("index.html",form=form)
            #f.close() 
           
        else: 
            return render_template("index.html",data=data,form=form)
       
     
    return app    